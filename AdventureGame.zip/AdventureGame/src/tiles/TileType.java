package tiles;

public enum TileType
{
	GRASS,
	MUD,
	ROAD,
	TRAP
}
