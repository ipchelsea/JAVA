package game;

import java.util.Random;
import java.util.Scanner;

import players.Player;
import tiles.BasicTile;

public class Game {
	private static Scanner kb = new Scanner(System.in);
	
	// stores tile objects
	private BasicTile[] tiles;
	

	/*
	 * stores the index of player (which tile the player is located within inside
	 * the tiles array
	 */
	private int position = -1;

	// the player object
	private Player player;

	public Game(int numTiles, Player player) {
		
	}

	// public methods

	public void startGame() {
		// this creates our array of tile objects
		buildTiles();

		/*
		 * The main game loop should be declared here. Each turn the player should move
		 * a random distance forward from 1 tmaxSteps.
		 * 
		 * NOTE: maxSteps should be stored in the Player class and should be 2 for
		 * Knights and 3 for squires or princesses.
		 */
		boolean gameOver = false;
		Random gen = new Random();
		while (!gameOver) {
			System.out.print("Do you want to quit playing?(true/false) ");
			gameOver = kb.nextBoolean();
			
		}

		System.out.println("Thank you for playing");

	}

	public Player getPlayer() {
		return player;
	}

	public boolean movePlayer(int distance) {
		/*
		 * This method moves the player the given distance. A positive value will move
		 * the player to the later indices in the tiles[] array, while a negative value
		 * will move the player back to lower indices.
		 * 
		 * Return false if the distance passed falls outside the range 0 -->
		 * tiles.length - 1
		 */
		return false;
	}

	// private methods
	private void buildTiles() {
		/*
		 * This method should instantiate tile objects to fill the tiles[] array above.
		 * 10% of the tiles should be trap tiles, 20% mud, 40% grass and 30% road.
		 */
		
	}

	// prints out the tiles array along with the current player position
	@Override
	public String toString() {
		String result = "[";

		for (int i = 0; i < tiles.length; i++) {
			if (i != 0) {
				result += ", ";
			}

			// player is in this tile
			if (position == i) {
				result += tiles[i].toString() + " - (player)";
			} else {
				result += tiles[i].toString();
			}
		}
		result += "]";

		if (position >= tiles.length) {
			result += " (player)";
		}

		return result;
	}
}
